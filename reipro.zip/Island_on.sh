iptables -I INPUT -p tcp --dport 17000 -j DROP
iptables -I INPUT -p tcp --dport 9030 -j DROP
iptables -I INPUT -p tcp --dport 443 -j DROP
iptables -I INPUT -p tcp --dport 8086 -j DROP
iptables -I INPUT -p tcp --dport 8085 -j DROP
iptables -I INPUT -p tcp --dport 8088 -j DROP
iptables -I INPUT -p tcp --dport 18081 -j DROP
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I INPUT -p tcp --dport 8011 -j DROP
iptables -I INPUT -p tcp --dport 8013 -j DROP
iptables -I INPUT -p tcp --dport 20001 -j DROP
iptables -I INPUT -p tcp --dport 20371 -j DROP
iptables -I INPUT -p tcp --dport 15692 -j DROP
iptables -I INPUT -p tcp --dport 20000 -j DROP
iptables -I INPUT -p tcp --dport 10040 -j DROP
iptables -I INPUT -p tcp --dport 10092 -j DROP

iptables -I INPUT -p udp --dport 443 -j DROP
iptables -I INPUT -p udp --dport 17000 -j DROP
iptables -I INPUT -p udp --dport 8011 -j DROP
iptables -I INPUT -p udp --dport 20001 -j DROP
iptables -I INPUT -p udp --dport 8013 -j DROP
iptables -I INPUT -p udp --dport 20000 -j DROP
iptables -I INPUT -p udp --dport 10040 -j DROP
iptables -I INPUT -p udp --dport 10092 -j DROP



iptables -I OUTPUT -p tcp --dport 17000 -j DROP
iptables -I OUTPUT -p tcp --dport 9030 -j DROP
iptables -I OUTPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p tcp --dport 8086 -j DROP
iptables -I OUTPUT -p tcp --dport 8085 -j DROP
iptables -I OUTPUT -p tcp --dport 8088 -j DROP
iptables -I OUTPUT -p tcp --dport 18081 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 8011 -j DROP
iptables -I OUTPUT -p tcp --dport 8013 -j DROP
iptables -I OUTPUT -p tcp --dport 20001 -j DROP
iptables -I OUTPUT -p tcp --dport 20371 -j DROP
iptables -I OUTPUT -p tcp --dport 15692 -j DROP
iptables -I OUTPUT -p tcp --dport 20000 -j DROP
iptables -I OUTPUT -p tcp --dport 10040 -j DROP
iptables -I OUTPUT -p tcp --dport 10092 -j DROP

iptables -I OUTPUT -p udp --dport 443 -j DROP
iptables -I OUTPUT -p udp --dport 17000 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I OUTPUT -p udp --dport 8013 -j DROP
iptables -I OUTPUT -p udp --dport 20000 -j DROP
iptables -I OUTPUT -p udp --dport 10040 -j DROP
iptables -I OUTPUT -p udp --dport 10092 -j DROP

iptables -I INPUT -s sg.tdatamaster.com -j DROP
iptables -I OUTPUT -s sg.tdatamaster.com -j DROP
iptables -I INPUT -s csi.gstatic.com -j DROP
iptables -I OUTPUT -s csi.gstatic.com -j DROP
iptables -I INPUT -s napubgm.broker.amsoveasea.com -j DROP
iptables -I OUTPUT -s napubgm.broker.amsoveasea.com -j DROP
iptables -I INPUT -s qos.hk.gcloudcs.com -j DROP
iptables -I OUTPUT -s qos.hk.gcloudcs.com -j DROP
iptables -I INPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP
iptables -I OUTPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP
iptables -I INPUT -s android.crashsight.wetest.net -j DROP
iptables -I OUTPUT -s android.crashsight.wetest.net -j DROP